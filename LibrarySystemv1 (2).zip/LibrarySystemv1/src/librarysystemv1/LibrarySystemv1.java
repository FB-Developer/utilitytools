/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author PCD
 */
package librarysystemv1;
public class LibrarySystemv1 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.err.println("Hello There"); 
        new MainFrame().setVisible(true);
    }    
}
